// Implementatie voor de lijst

#include "lijst17.h"

template <class T>
ostream& operator<<(ostream& os, const Lijst<T>& l) {
    if (l.get()) {
        os << l.get()->sleutel << ", ";
        os << l.get()->volgend;
    }
    return os;
}

template <class T>
void Lijst<T>::schrijf(ostream& os) const {
    if (this->get() != 0) {
        os << this->get()->sleutel;
        std::for_each(++begin(), end(),
                      [&](const T& sleutel) { os << " . " << sleutel; });
    }
}

// oplossing:

template <class T>
bool Lijst<T>::isClone(const Lijst<T>& ander) const {
    const Lijst<T>*l1 = this, *l2 = &ander;  // twee lopers
    while (*l1 && *l2 && (*l1)->sleutel == (*l2)->sleutel) {
        l1 = &((*l1)->volgend);
        l2 = &((*l2)->volgend);
    };
    return (!(*l1) && !(*l2));
};

template <class T>
const Lijst<T>* Lijst<T>::zoek(const T& sleutel) const {
    const Lijst<T>* pl = this;
    while (*pl && pl->get()->sleutel != sleutel) pl = &(pl->get()->volgend);
    return pl;
}

template <class T>
int Lijst<T>::geefAantal(const T& sleutel) const {
    int aantal = 0;
    const Lijst<T>* pl = this;
    while (*pl) {
        if ((sleutel = (*pl)->sleutel)) ++aantal;
        pl = &(pl->get()->volgend);
    };
    return aantal;
};

template <class T>
int Lijst<T>::geefAantal() const {
    int aantal = 0;
    const Lijst<T>* pl = this;
    while (*pl) {
        ++aantal;
        pl = &(pl->get()->volgend);
    };
    return aantal;
};

template <class T>
Lijst<T>* Lijst<T>::zoek(const T& sleutel) {
    Lijst* pl = this;
    while (*pl && pl->get()->sleutel != sleutel) pl = &(pl->get()->volgend);
    return pl;
}

template <class T>
void Lijst<T>::voegToe(const T& sleutel) {
    Lijstknoopptr<T> nieuw = std::make_unique<Lijstknoop<T>>(sleutel);

    // Deze code is identiek aan de volgende lijn code
    // Lijstknoopptr<T>::swap(nieuw->volgend);
    // Aangezien een Lijst eigenlijk gewoon een lijstknoopptr is zou dit ook
    // moeten lukken

    // We zorgen dat de volgende van de nieuwe wijst naar het begin van de lijst
    this->swap(nieuw->volgend);

    // Het begin van de lijst verplaatsen we nu naar nieuw. Aangezien de
    // rest bij volgende staat is de nieuwe knoop nu dus vooraan ingevoegd

    // We moeten dus een move operator schrijven met een lijstknoopptr als
    // argument
    *this = std::move(nieuw);
}

template <class T>
void Lijst<T>::verwijderEerste() {
    if (this->get() != 0) {
        Lijstknoopptr<T> staart(std::move(this->get()->volgend));
        this->reset();
        Lijstknoopptr<T>::swap(staart);
    }
}

template <class T>
void Lijst<T>::verwijder(const T& sleutel) {
    zoek(sleutel)->verwijderEerste();
}

template <class T>
Lijst<T>* Lijst<T>::zoekGesorteerd(const T& sleutel) {
    Lijst* plaats = this;
    while (*plaats && plaats->get()->sleutel < sleutel)
        plaats = &plaats->get()->volgend;
    return plaats;
};

template <class T>
void Lijst<T>::insertionsort() {
    Lijstknoopptr<T> ongesorteerd = std::move(*this);
    while (ongesorteerd) {
        Lijst* plaats = zoekGesorteerd(ongesorteerd.get()->sleutel);
        Lijstknoopptr<T> dummy = std::move(ongesorteerd);
        // vermits ongesorteerd een nullpointer is, is het equivalent van
        // volgende lijnen ongeveer
        // ongesorteerd=std::move(dummy.get()->volgend);
        // std::swap(*plaats,dummy.get()->volgend);
        std::swap(ongesorteerd, dummy.get()->volgend);
        dummy.get()->volgend = std::move(*plaats);
        *plaats = std::move(dummy);
    };
};

template <class T>
void Lijst<T>::teken(const char* bestandsnaam) const {
    ofstream uit(bestandsnaam);
    assert(uit);
    uit << "digraph "
           "{\nrankdir=\"LR\";\n\"0\"[label=\"\",shape=diamond];\n\"0\" -> "
           "\"1\";\n";
    int knoopteller = 1;  // knopen moeten een eigen nummer krijgen.
    const Lijst<T>* loper = this;
    while (*loper) {
        uit << "subgraph cluster_" << knoopteller << " {\nrankdir=\"LR\";\n";
        uit << "\"" << knoopteller << "\" [label=\"" << (*loper)->sleutel
            << "\",color=white];\n";
        uit << "\"" << knoopteller << "v\" [shape=diamond,label=\"\"];\n";
        uit << "\"" << knoopteller << "\" -> \"" << knoopteller
            << "v\" [color=white];\n";

        uit << "}\n";
        uit << "\"" << knoopteller << "v\" -> \"" << knoopteller + 1
            << "\" [lhead=cluster_" << knoopteller << " ltail=cluster_"
            << knoopteller + 1 << "];\n";
        loper = &((*loper)->volgend);
        knoopteller++;
    };
    uit << "\"" << knoopteller << "\" [shape=point];\n";
    uit << "}";
};
