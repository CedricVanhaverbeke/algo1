// C++17-compatibele lijst. Ontbrekende elementen: move en copy, iterator
#include "includes.h"

using std::endl;
using std::ofstream;
using std::ostream;
using std::string;

// Moet er staan om de << en >> operator te kunnen implementeren
// Als een friend functie
template <class T>
ostream& operator<<(ostream& os, const Lijst<T>& l);

template <class T>
class Lijst : private Lijstknoopptr<T> {
   public:
    // toekenning, constructoren
    // overname constructoren van unique_ptr

    // te doen....

    // operaties
    // duplicaten zijn toegelaten.

    void voegToe(const T&);

    // geefaantal geeft het aantal keer dat de sleutel voorkomt.
    // gebruikt de zoekfunctie om door de lijst te lopen!
    // zonder argument: geef lengte lijst
    int geefAantal(const T&) const;
    void teken(const char* bestandsnaam) const;
    int geefAantal() const;

    // verwijder verwijdert slechts het eerste exemplaar met de gegeven
    // T, en geeft geen fout als de T niet gevonden wordt.
    // gebruik de zoekfunctie om door de lijst te lopen!
    void verwijder(const T&);

    // verwijder eerste knoop.
    void verwijderEerste();

    void insertionsort();

    bool isClone(const Lijst<T>&) const;

    // uitschrijven: voor elke knoop de T-waarde, gescheiden door komma's
    friend ostream& operator<<<>(ostream& os, const Lijst& l);

   public:
    void schrijf(ostream& os) const;

    // iterator; gaat ervan uit dat alles const is
   public:
    class iterator {
       public:
        iterator(Lijstknoop<T>* l = 0);
        const T& operator*() const;
        const iterator& operator++();
        bool operator!=(const iterator& i);
    };
    iterator begin() const;
    iterator end() const;

   protected:
    // zoek geeft een pointer naar de Lijst die de sleutelwaarde bevat,
    // en geeft een pointer naar de lege lijst op het einde als de sleutel niet
    // voorkomt.
    const Lijst* zoek(const T&) const;

    Lijst* zoek(const T&);
    // preconditie zoekgesorteerd: lijst is gesorteerd
    // teruggeefwaarde: wijst naar Lijst waar sleutel staat/zou moeten staan.

    Lijst<T>* zoekGesorteerd(const T& sleutel);
};
